<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="Semantic/semantic.css">
  <script type="text/javascript" href="Semantic/semantic.js"></script>
  <link rel="stylesheet" type="text/css" href="css/menu.css">
  <link rel="stylesheet" type="text/css" href="css/login.css">
  <link rel="stylesheet" type="text/css" href="css/trabalho.css">
  <link rel="stylesheet" type="text/css" href="css/animate.min.css">
  <link rel="stylesheet" type="text/css" href="css/minhas_resenhas.css">
  
</head>
<body>
  <header>
<div class="topnav" id="myTopnav">
  <a><img src="logo.png" id="logo_responsa"></a>
  <a href="index.php" class="active">Home</a>
  <a href="#news">Resenhas</a>
  <a href="#contact">Cadastro</a>
  <a href="#about">Sobre</a>
  <a href="minhas_resenhas.html">Usuário</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>


<script type="text/javascript">
  function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</header>
