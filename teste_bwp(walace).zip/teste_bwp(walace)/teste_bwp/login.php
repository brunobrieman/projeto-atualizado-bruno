<?php
session_start();

$login = $_POST['login'];
$senha = $_POST['senha'];


if ($login=='admin' and $senha=='admin') {
//logou como admistrador e acertou na senha	
	echo "ola, administrador";
	
	//guardando informacao na sessao
	$_SESSION['nome']="admin";
	$_SESSION['login']="admin";
	
	//redireciona para a pagina do administrador
	echo '<meta http-equiv="refresh" content="3;url=minhas_resenhas.php">';
}else{
	echo "dados invalidos";
	//redireciona para a pagina inicial
	echo '<meta http-equiv="refresh" content="3;url=minhas_resenhas.php">';
}