<?php
 include("funcoes.php");
 include("cabecalho.php");
 ?>

 <?php
 echo'
  <div class="butao_responsa"><button class="button"><span>Resenhas </span></button></div>';
 $lista=listaResenhas();
 $cont = 0;
 
  foreach ($lista as $dados) {
    $cont++;
    if ($cont>3) {
        break;
    }else{

   



echo '

  
<div class="responsive">
  <div class="gallery">
     <a href="detalha_resenha.php?cod='.$dados["cod_jogo"].'">
      <img src="imagens/'.$dados['foto'].'" alt="Trolltunga Norway" width="300" height="200">
       
    </a>
    <div class="desc">'.$dados['Nome'].'</div>
  </div>
</div>
';

}
}
?>
