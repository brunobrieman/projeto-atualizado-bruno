<?php
include 'cabecalho.php';

 include("funcoes.php");

 
 ?>

<body>
 
 

 <?php
 $lista=listaResenhas();
 $cont=0;
  foreach ($lista as $dados) {
  	$cont ++;
  	if ($cont>12) {
  		break;

  	}else{

echo'

  
<div class="responsive">
  <div class="gallery">
    
     <a href="detalha_resenha.php?cod='.$dados["cod_jogo"].'">

     	<img src="imagens/'.$dados["foto"].'" width="300" height="200">
       
    </a>
    <div class="desc">'.$dados['Nome'].'</div>
  </div>
</div>



';
}
}

?>
