<?php

function listaResenhas(){
	$resenha= array();

	$dados= file("dados.csv");

	foreach ($dados as $posicao => $linha) {
		if ($posicao !=0) {
		$colunas= explode(";",$linha);
			$resenha['cod_jogo'] =$colunas[0];
			$resenha['Nome'] =$colunas[1];
			$resenha['Resenha'] =$colunas[2];
			$resenha['Ano'] =$colunas[3];
			$resenha['foto'] =$colunas[4];
			$resenhas[]=$resenha;
		}
			
	}
	return $resenhas;
}

function buscaResenha($codigo){

	$resenha= array();

	$dados= file("dados.csv");

	foreach ($dados as $linha) {
		$colunas= explode(";",$linha);
		if($colunas[0]==$codigo){
			$resenha['cod_jogo'] =$colunas[0];
			$resenha['Nome'] =$colunas[1];
			$resenha['Resenha'] =$colunas[2];
			$resenha['Ano'] =$colunas[3];
			$resenha['foto'] =$colunas[4];
			$resenha['foto1'] =$colunas[5];
			$resenha['foto2'] =$colunas[6];
			$resenha['foto3'] =$colunas[7];
			$resenha['video'] =$colunas[8];
			
		}
	}
	return $resenha;
}
